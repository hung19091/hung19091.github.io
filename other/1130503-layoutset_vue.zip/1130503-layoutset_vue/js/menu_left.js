export default {
	template: `
	<!-- #menuL 左サイドメニュー -->
	<div class="subinfo">
		<div class="label">文章分類</div>
		<ul>
			<li><a href="/page/portfolio.html">作品集</a></li>
			<li><a href="/page/hobby">休閒娛樂</a></li>
			<li><a href="javascript:">知識分享</a></li>
			<li><a href="javascript:">隨筆札記</a></li>
		</ul>
	</div>
	<div class="subinfo">
		<div class="label">簡介</div>
		<p>大塚 宏，興趣是收集所有卡片形狀的酷東西。工作技能：C#、VB.NET、JavaScript、MSSQL、Informix、日檢N1通過</p>
	</div>
	<div class="subinfo">
		<div class="label">贊助商</div>
		<div align="center">
			<iframe id="frame_admax" src="page/admax.html" width="170px" scrolling="no" onload="resizeIframe(this)"/></iframe>
		</div>
	</div>
	`
}