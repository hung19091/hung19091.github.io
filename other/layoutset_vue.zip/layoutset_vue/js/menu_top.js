export default {
  template: `
	<!-- #headerer 画面上部のヘッダー -->
	<div id="header">
		<div id="sitename">サイト名サイト名</div>
	</div>
	<div id="menu">
		<ul class="menu_f02">
			<li><a href="#">Home</a></li>
			<li><a href="#">メニュー１</a></li>
			<li><a href="#">メニュー２</a></li>
			<li><a href="#">メニュー３</a></li>
			<li><a href="#">メニュー４</a></li>
			<li><a href="#">メニュー５</a></li>
		</ul>
	</div>
  `
}