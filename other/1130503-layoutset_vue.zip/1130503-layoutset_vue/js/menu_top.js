export default {
	template: `
	<!-- #headerer 画面上部のヘッダー -->
	<div id="header">
		<div id="sitename">大塚 宏プロジェクト</div>
	</div>
	<div id="menu">
		<ul class="menu_f02">
			<li><a href="/index.html">首頁</a></li>
			<li><a href="/page/portfolio.html">作品集</a></li>
			<li><a href="/page/hobby">休閒娛樂</a></li>
			<li><a href="javascript:">知識分享</a></li>
			<li><a href="javascript:">隨筆札記</a></li>
			<li><a href="javascript:">關於我</a></li>
			<li><a href="javascript:">管理介面</a></li>
		</ul>
	</div>
	`
}