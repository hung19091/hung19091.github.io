function resizeIframe(obj) {
	obj.style.height = 0;
	obj.style.height = obj.contentWindow.document.documentElement.scrollHeight + 'px';
}
function changeSrc(url) {
	document.getElementById('frame').src = url;
}