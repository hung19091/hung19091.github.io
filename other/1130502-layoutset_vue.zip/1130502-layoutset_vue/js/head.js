//動態載入head內容，包含title、meta標籤、載入script

//獲取head元素
var head = document.querySelector('head');

document.title = '大塚 宏プロジェクト';

//meta設定
var charsetMata = document.createElement('meta');
charsetMata.setAttribute('charset', 'UTF-8');
head.appendChild(charsetMata); //將新的meta標籤添加到head中

var authorMata = document.createElement('meta');
authorMata.name = 'author';
authorMata.content = '大塚 宏';
head.appendChild(authorMata);

var copyrightMata = document.createElement('meta');
copyrightMata.name = 'copyright';
copyrightMata.content = '本網頁著作權屬大塚 宏所有';
head.appendChild(copyrightMata);

//載入BootStrap
var bootstrapLink = document.createElement('link');
bootstrapLink.href = 'https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css';
bootstrapLink.rel="stylesheet";
head.appendChild(bootstrapLink);

var bootstrapScript = document.createElement('script');
bootstrapScript.src = 'https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js';
head.appendChild(bootstrapScript);

var commonScript = document.createElement('script');
commonScript.src = 'js/common.js';
head.appendChild(commonScript);

var styleLink = document.createElement('link');
styleLink.href = 'css/stylet.css?ver=20240428';
styleLink.rel = 'stylesheet';
styleLink.type = 'text/css';
head.appendChild(styleLink);

//載入media查詢
var rwdLink = document.createElement('link');
rwdLink.href = 'css/rwd.css';
rwdLink.rel = 'stylesheet';
rwdLink.type = 'text/css';
head.appendChild(rwdLink);

//頁面加載效果
window.addEventListener('load', function() {
	document.body.style.opacity = '1'; // 當頁面加載完成後，透明度改為1，顯示內容
});

/*
// 檢查 CDN 是否可用的函數
function checkCDN(callback) {
    var script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js';
    script.onload = function() {
        callback(true);
    };
    script.onerror = function() {
        callback(false);
    };
    document.body.appendChild(script);
}

// 如果 CDN 失效，切換到本地資源
checkCDN(function(available) {
    if (!available) {
        // 如果 CDN 失效，使用本地 jQuery
        var localjQuery = document.createElement('script');
        localjQuery.src = 'path/to/jquery.min.js';
        document.body.appendChild(localjQuery);

        // 如果 CDN 失效，使用本地 Bootstrap
        var localBootstrapCSS = document.createElement('link');
        localBootstrapCSS.rel = 'stylesheet';
        localBootstrapCSS.href = 'path/to/bootstrap.min.css';
        document.head.appendChild(localBootstrapCSS);
    }
});
*/