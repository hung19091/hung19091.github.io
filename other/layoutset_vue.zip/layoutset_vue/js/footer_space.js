export default {
  template: `
	<!-- #footer　フッタースペース -->
	<div id="footer" class="col-5 col-sm-auto"> Copyright (c) 20XX yourname </div>
	<div id="templatelink"> HTML &amp; CSS template by <a href="http://www.shoshinsha.com/hp/template/">CSSデザインテンプレート</a> </div>
  `
}