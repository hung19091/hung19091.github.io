export default {
  template: `
	<!-- #menuL 左サイドメニュー -->
	<div class="subinfo">
		<div class="label">サブカテゴリ</div>
		<ul>
			<li><a href="#">知らないと損する○○</a></li>
			<li><a href="#">○○するための７つの方法</a></li>
			<li><a href="#">あまり知られていない○○の法則</a></li>
		</ul>
	</div>
	<div class="subinfo">
		<div class="label">サブカテゴリ</div>
		<ul>
			<li><a href="#">知らないと損する○○</a></li>
			<li><a href="#">○○するための７つの方法</a></li>
			<li><a href="#">あまり知られていない○○の法則</a></li>
		</ul>
	</div>
	<div class="subinfo">
		<div class="label">サブカテゴリ</div>
		<ul>
			<li><a href="#">知らないと損する○○</a></li>
			<li><a href="#">○○するための７つの方法</a></li>
			<li><a href="#">あまり知られていない○○の法則</a></li>
		</ul>
	</div>
	<div class="subinfo">
		<div class="label">プロフィール</div>
		<p>トップページに自己紹介や経歴・サイトのテーマなど書いておくと、それがないサイトよりも印象がよくなります。別にプロフィールページを作り、体験談や印象に残っている出来事を書き留めておくとよいかも。</p>
	</div>
  `
}