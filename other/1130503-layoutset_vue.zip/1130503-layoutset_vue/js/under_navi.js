export default {
	template: `
	<div class="contentswrap">
		<!-- <p>サイト内の他ページへのナビスペース</p> -->
	</div>
	`
}