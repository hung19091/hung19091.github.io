import { createApp, ref, computed } from 'vue'
import menuTop from '/js/menu_top.js?ver=20240503'
import menuLeft from '/js/menu_left.js?ver=20240504'
import underNavi from '/js/under_navi.js'
import footerSpace from '/js/footer_space.js'

createApp({
	components: {
		menuTop,
		menuLeft,
		underNavi,
		footerSpace
	}
}).mount('#app')